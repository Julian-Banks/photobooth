-- ~/.config/nvim/lua/plugins/telescope.lua
return {
  "nvim-telescope/telescope.nvim",
  version = false, -- or tag = '0.1.2' for stability
  dependencies = {
    "nvim-lua/plenary.nvim",
    "nvim-telescope/telescope-fzf-native.nvim",
  },
  build = "make", -- for telescope-fzf-native
  config = function()
    local telescope = require("telescope")
    local actions = require("telescope.actions")

    telescope.setup({
      defaults = {
        mappings = {
          i = {
            ["<esc>"] = actions.close,
          },
        },
        layout_strategy = "vertical",
        layout_config = {
          preview_cutoff = 0,
        },
      },
    })

    -- Load fzf native extension for speed
    pcall(telescope.load_extension, "fzf")
  end,
}
