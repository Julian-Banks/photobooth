local M = {}

function M.rename_file(old, new)
  if not old or not new then
    vim.notify("Usage :Rf old_name new_name", vim.log.levels.ERROR)
    return
  end

  vim.cmd("saveas " .. new)

  vim.fn.delete(old)

  vim.cmd("bdelete " .. old)

  vim.cmd("edit " .. new)

  vim.notify("Renamed: " .. old .. "->" .. new, vim.log.levels.INFO)
end

return M
