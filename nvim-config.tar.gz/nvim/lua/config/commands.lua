vim.api.nvim_create_user_command("Rf", function(opts)
  local args = opts.fargs
  if #args ~= 2 then
    vim.notify("Usage: :Rf old_path new_path", vim.logs.levels.ERROR)
    return
  end
  require("utils.rename_file").rename_file(args[1], args[2])
end, {
  nargs = "*",
  desc = "Rename file: Rf old_path new_path",
})
